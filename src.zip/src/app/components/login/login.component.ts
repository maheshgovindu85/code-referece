import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { LocalstorageService } from '../guards/localstorage.service';
import { BehaviorSubject } from 'rxjs';
import { PrimengModule } from '../../primeng/primeng.module';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule,PrimengModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  private currentUserSubject = new BehaviorSubject<any>(null);
  constructor(
    private authService: AuthService,
    private router: Router,
    private fb: FormBuilder,
    private messageService: MessageService
  ) {

  }

  ngOnInit(): void {
    this.createform()
  }

  createform() {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }


  onSubmit() {
    this.authService.login(this.loginForm.value.email, this.loginForm.value.password).subscribe(response => {
      if (response.status) {
        this.authService.setLocalStorage(response)
        this.currentUserSubject.next(response.employee);
        this.messageService.add({ severity: 'success', summary: 'Success', detail: response.message });
        if (response.employee.role === 'admin') {
          this.router.navigate(['/admin/attendance-history']);
        } else {
          this.router.navigate(['/employee/attendance-history']);
        }
      } else {
        alert(response.message);
      }

    });
  }
}
