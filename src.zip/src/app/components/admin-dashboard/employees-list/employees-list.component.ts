import { Component, inject } from '@angular/core';
import { EmployeeService } from '../../services/employee.service';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router, RouterModule } from '@angular/router';
import { PrimengModule } from '../../../primeng/primeng.module';
@Component({
  selector: 'app-employees-list',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule,PrimengModule ],
  templateUrl: './employees-list.component.html',
  styleUrl: './employees-list.component.scss',
})
export class EmployeesListComponent {
  form!: FormGroup;
  first: number = 0;
  rows: number = 10;

  onPageChange(event: any) {
      this.first = event.first;
      this.rows = event.rows;
  }
  
  employeeList: any[] = [];
  employeeService = inject(EmployeeService);
  isVisibile: boolean = false;
  loading = false;
  authService = inject(AuthService);
  router = inject(Router);
  private fb = inject(FormBuilder)
  constructor(
  ) { }

  ngOnInit() {
    this.createform()
    this.getList();
  }

  createform() {
    this.form = this.fb.group({
      name: ['', [Validators.required]],
      role: ['', [Validators.required]],
      phone: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', [Validators.required, Validators.minLength(6)]]
    });
  }


  getList() {
    this.employeeService.getEmployeeList().subscribe(data => {
      this.employeeList = data['data'];
    });
  }

  openEmpForm() {
    this.isVisibile = true
  }

  onSubmit(): void {
    if (this.form.invalid) {
      return;
    }
    if (this.form.value.password !== this.form.value.confirmPassword) {
      alert('Passwords do not match')
      return;
    }

    this.loading = true;
    this.authService.register(this.form.value).subscribe({
      next: () => {
        alert('Registration successful! Please login.');
        this.router.navigate(['/login']);
      },
      error: (error) => {
        this.loading = false;
        alert({
          severity: 'error',
          summary: 'Error',
          detail: error.error.message || 'Registration failed'
        });
      }
    });
  }
}
