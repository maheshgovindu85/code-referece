import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AttendanceService {

  constructor(
    private http: HttpClient,
    private authService: AuthService,

  ) {}

  punchIn(employee_id: number, location: string, ip_address: string): Observable<any> {
    return this.http.post(`${environment.apiUrl}/attendance/punch-in`, { employee_id, location, ip_address });
  }
  
  punchOut(employee_id: number): Observable<any> {
    return this.http.post(`${environment.apiUrl}/attendance/punch-out`, { employee_id });
  }

  getAttendanceId(employee_id: number): Observable<any> {
    return this.http.post(`${environment.apiUrl}/attendance/getAttendanceById`, { employee_id });
  }

  getAttendanceList(): Observable<any> {
    const role = this.authService.getUserRole();
    const userId = +this.authService.getEmployeeId();

    const body = {
      role: role,
      userId: userId,
    };

    return this.http.post(`${environment.apiUrl}/attendance/getAttendanceList`, body);
  }
}
