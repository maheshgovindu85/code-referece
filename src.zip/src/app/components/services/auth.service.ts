import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Router } from '@angular/router';
import { LocalstorageService } from '../guards/localstorage.service';
import * as CryptoJS from 'crypto-js';
@Injectable({
  providedIn: 'root'
})
export class AuthService {

  http = inject(HttpClient);
  router = inject(Router);
  _localstorage = inject(LocalstorageService);
  private readonly secretKey = 'your-secret-key'; 
  constructor() {}

  login(email: string, password: string): Observable<any> {
    return this.http.post(`${environment.apiUrl}/auth/login`, { email, password });
  }
  
  register(employee: any): Observable<any> {
    return this.http.post(`${environment.apiUrl}/auth/register`, employee);
  }
  
  logout() {
    this._localstorage.removeItem('token');
    this._localstorage.clear();
    this.router.navigate(['/']);
  }

  isAuthenticated(): boolean {
    return !!this._localstorage.getItem('token');
  }

  getUserRole(): string {
    return this.getDecryptedItem('loginRole') || '';
  }
  getEmployeeId(): string {
    return this.getDecryptedItem('employeeId') || '';
  }


  setLocalStorage(response:any){
    this._localstorage.setItem('token', response.token);
    this.setEncryptedItem('employeeId',response.employee.id.toString());
    this.setEncryptedItem('loginRole',response.employee.role);
  }

  setEncryptedItem(key: string, value: string): void {
    const encryptedValue = this.encrypt(value);
    this._localstorage.setItem(key, encryptedValue);
  }

  encrypt(data: string): string {
    return CryptoJS.AES.encrypt(data, this.secretKey).toString();
  }

  getDecryptedItem(key: string): string | null {
    const encryptedValue = this._localstorage.getItem(key);
    return encryptedValue ? this.decrypt(encryptedValue) : null;
  }
  
  decrypt(encryptedData: string): string {
    const bytes = CryptoJS.AES.decrypt(encryptedData, this.secretKey);
    return bytes.toString(CryptoJS.enc.Utf8);
  }
  
  private getAuthHeaders(): HttpHeaders {
    const token = this._localstorage.getItem('token');
    return new HttpHeaders({
      'Authorization': token ? `Bearer ${token}` : ''
    });
  }

}
