import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AttendanceMasterComponent } from './attendance-master.component';
import { provideHttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';

describe('AttendanceMasterComponent', () => {
  let component: AttendanceMasterComponent;
  let fixture: ComponentFixture<AttendanceMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AttendanceMasterComponent],
      providers:[
        provideHttpClient(),
        { provide: ActivatedRoute, useValue: { snapshot: { queryParams: {} } } },

      ]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AttendanceMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
