import { Routes } from '@angular/router';
import { EmployeeDashboardComponent } from './components/employee-dashboard/employee-dashboard.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { authGuard } from './components/guards/auth.guard';

export const routes: Routes = [
    { path: '', redirectTo: '/login', pathMatch: 'full' },

    {
        path: "login",
        loadComponent() {
            return import('./components/login/login.component').then(c => c.LoginComponent);
        },
    },

    {
        path: "register",
        loadComponent() {
            return import('./components/register/register.component').then(c => c.RegisterComponent);
        },
    },

    {
        path: "",
        loadComponent() {
            return import('./employee-attendence-master/attendance-master/attendance-master.component').then(c => c.AttendanceMasterComponent);
        },
        canActivate: [authGuard],
        children: [
            {
                path: "admin",
                component: AdminDashboardComponent,
                canActivate: [authGuard],
                data: { role: 'admin' },
                children: [
                    {
                        path: "dashboard",
                        loadComponent() {
                            return import('./components/admin-dashboard/admin-dashboard.component').then(c => c.AdminDashboardComponent);
                        },
                    },
                    {
                        path: "employees-list",
                        loadComponent() {
                            return import('./components/admin-dashboard/employees-list/employees-list.component').then(c => c.EmployeesListComponent);
                        },
                        canActivate: [authGuard]
                    },
                    {
                        path: "attendance-history",
                        loadComponent() {
                            return import('./components/admin-dashboard/attendance-history/attendance-history.component').then(c => c.AttendanceHistoryComponent);
                        },
                        canActivate: [authGuard]
                    },
                ]
            },

            {
                path: "employee",
                component: EmployeeDashboardComponent,
                canActivate: [authGuard],
                data: { role: 'employee' },
                children: [
                    {
                        path: "dashboard",
                        loadComponent() {
                            return import('./components/employee-dashboard/employee-dashboard.component').then(c => c.EmployeeDashboardComponent);
                        },
                    },
                    {
                        path: "profile",
                        loadComponent() {
                            return import('./components/employee-dashboard/profile/profile.component').then(c => c.ProfileComponent);
                        },
                        canActivate: [authGuard]
                    },
                    {
                        path: "employee-attendance",
                        loadComponent() {
                            return import('./components/employee-dashboard/profile/profile.component').then(c => c.ProfileComponent);
                        },
                        canActivate: [authGuard]
                    },
                ]
            }
        ],
    },
];
