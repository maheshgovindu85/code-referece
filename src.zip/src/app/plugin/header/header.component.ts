import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { LocalstorageService } from '../../components/guards/localstorage.service';
import { AttendanceService } from '../../components/services/attendance.service';
import { AuthService } from '../../components/services/auth.service';
import { ButtonModule } from 'primeng/button';
@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive,ButtonModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent {
  attendanceRecords: any[] = [];
  isPunchedIn = false;
  duration = '00:00:00';
  private startTime: Date | null = null;
  private timer: any;
  employeeId!: number;
  constructor(
    private attendanceService: AttendanceService,
    private http: HttpClient,
    private _localstorage: LocalstorageService,
    private authService: AuthService,
  ) { }

  menuItems = [
    // { label: 'Dashboard', link: '/admin/dashboard', icon: 'bi-house-door', roles: ['admin', 'employee'] },
    { label: 'Employee', link: '/admin/employees-list', icon: 'bi-person', roles: ['admin'] },
    { label: 'Attendance History', link: '/admin/attendance-history', icon: 'bi-gear', roles: ['admin'] },
    { label: 'Attendance', link: '/employee/employee-attendance', icon: 'bi-check-circle', roles: ['employee'] },
  ];

  
  ngOnInit() {
    this.employeeId = +this.authService.getDecryptedItem('employeeId')!;
    this.getEmployeeDetails();
    this.getAttendanceByEmpId();
    this.updateMenuItems();
    
  }

  updateMenuItems(): void {
    const userRole = this.authService.getUserRole();
    this.menuItems = this.filterMenuItemsByRole(userRole);
  }

  filterMenuItemsByRole(role: string): any[] {
    return this.menuItems.filter(item => item.roles.includes(role));
  }


  getAttendanceByEmpId() {
    this.attendanceService.getAttendanceId(this.employeeId).subscribe(res => {
      if (res['data'] && res['data'].length > 0) {
        const latestAttendance = res['data'][res['data'].length - 1];  // Get the latest attendance record
        if (latestAttendance.punch_in && !latestAttendance.punch_out) {
          debugger
          this.isPunchedIn = true;
          this.startTime = new Date(latestAttendance.punch_in);
          this.startTimer(); 
        } else {
          this.isPunchedIn = false;
          this.duration = '00:00:00';
        }
      }
    });
  }
  

  
  getEmployeeDetails() {
    this.employeeId = JSON.parse(this.authService.getDecryptedItem('employeeId')!);
  }

  punchIn(): void {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return;
    }

    // Step 1: Get the current location
    navigator.geolocation.getCurrentPosition((position) => {
      const location = `${position.coords.latitude},${position.coords.longitude}`;

      // Step 2: Get the IP address
      this.http.get<any>('https://api.ipify.org?format=json').subscribe({
        next: (response) => {
          const ipAddress = response.ip;

          // Step 3: Call the punchIn service with location and IP address
          this.attendanceService.punchIn(this.employeeId, location, ipAddress).subscribe({
            next: () => {
              alert('Punched in successfully.');
              this.isPunchedIn = true;
              this.getAttendanceByEmpId()
              this.startTime = new Date();
              this.startTimer();
            },
            error: (error) => {
              alert('Failed to punch in. ' + (error.error.message || 'Please try again.')
              );
            }
          });
        },
        error: (err) => {
          alert('Failed to get IP address.');
        }
      });
    });
  }

  punchOut() {
    this.attendanceService.punchOut(this.employeeId).subscribe(() => {
      this.isPunchedIn = false;
      this.startTime = new Date();
      this.stopTimer();
    });
  }

  private startTimer() {
    this.timer = setInterval(() => {
      if (this.startTime) {
        const diff = new Date().getTime() - this.startTime.getTime();
        const hours = Math.floor(diff / 3600000);
        const minutes = Math.floor((diff % 3600000) / 60000);
        const seconds = Math.floor((diff % 60000) / 1000);
        this.duration = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
      }
    }, 1000);
  }

  private stopTimer() {
    if (this.timer) {
      clearInterval(this.timer);
      this.duration = '00:00:00';
    }
  }

  logout() {
    this.authService.logout();
  }
}
