import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../components/services/auth.service';
import { CardModule } from 'primeng/card';
@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink,CardModule],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.scss'
})
export class SidebarComponent {
  authService = inject(AuthService)
  menuItems = [
    { label: 'Dashboard', link: '/admin/dashboard', icon: 'bi-house-door', roles: ['admin', 'employee'] },
    { label: 'Employee List', link: '/admin/employees-list', icon: 'bi-person', roles: ['admin'] },
    { label: 'Attendance History', link: '/admin/attendance-history', icon: 'bi-gear', roles: ['admin'] },
    { label: 'Profile', link: '/employee/profile', icon: 'bi-person', roles: ['employee'] },
    { label: 'Attendance', link: '/attendance', icon: 'bi-check-circle', roles: ['employee'] },
    { label: 'Logout', link: '/logout', icon: 'bi-box-arrow-right', roles: ['admin', 'employee'] }
  ];

  constructor() { }

  ngOnInit(): void {
    this.updateMenuItems();
  }
  updateMenuItems(): void {
    const userRole = this.authService.getUserRole();
    this.menuItems = this.filterMenuItemsByRole(userRole);
  }

  filterMenuItemsByRole(role: string): any[] {
    return this.menuItems.filter(item => item.roles.includes(role));
  }
}
