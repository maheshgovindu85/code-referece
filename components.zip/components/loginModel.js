
"use client";
import React, { useState, useEffect } from 'react';
import styles from "./Modal.module.css";
export default function LoginModal({ show, onClose, onNext }) {
    const [phone, setPhone] = useState("");
    useEffect(() => {
        if (show) {
            setPhone("");
        }
    }, [show]);
    if (!show) return null;

    const handleSubmit = (e) => {
        e.preventDefault();
        if (phone.trim().length >= 6) {
            onNext(); // Show OTP modal
        } else {
            alert("Veuillez entrer un numéro valide.");
        }
    };
    return (
        <>
          <style>
                {`
           .selection-box{
               border: 1px solid #ccc;
                border-radius: 5px;
                padding: 3px;
           }
                .form-select {
                border: 0;
                border-bottom: 1px solid #ccc;
                border-radius: 0;
                
                }

                .form-control {
                 border: 0;
                }

                
                .form-control:focus {
                 outline: none;
                 box-shadow: none 
                }

       `}
            </style>
        <div className="modal d-block" tabIndex="-1" style={{ background: 'rgba(0,0,0,0.5)' }}>
            <div className={`modal-dialog modal-dialog-centered modal-fullscreen-sm-down ${styles["modal-top-spacing"]}`}>


                <div className="modal-content rounded-4 shadow">
                    <div className="modal-header">
                        <button type="button" className="btn-close" onClick={onClose}></button>
                        <h5 className="modal-title w-100 text-center fw-bold">Connexion</h5>
                    </div>
                    <form onSubmit={handleSubmit}>
                        <div className="modal-body">
                            <h5 className="mb-4">Ravis de vous revoir</h5>

                            <div className="mb-3 selection-box">
                                <select className="form-select mb-2">
                                    <option>France (+33)</option>
                                    <option>India (+91)</option>
                                    <option>USA (+1)</option>
                                </select>
                                <input type="tel" className="form-control" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Numéro de téléphone" />
                            </div>

                            <button className="btn btn-primary w-100 mb-3">Suivant</button>

                            <div className="d-flex align-items-center my-3">
                                <hr className="flex-grow-1" />
                                <span className="mx-2 text-muted">ou</span>
                                <hr className="flex-grow-1" />
                            </div>

                            <button className="btn btn-outline-secondary w-100 mb-2 d-flex justify-content-between align-items-center">
                                <i class="bi bi-envelope"></i>
                                <span className="flex-grow-1 text-center">Continuer avec Facebook</span>
                                <span style={{ width: '1.5rem' }}></span>
                            </button>
                            <button className="btn btn-outline-secondary w-100 mb-2 d-flex justify-content-between align-items-center">
                                <i className="bi bi-facebook"></i>
                                <span className="flex-grow-1 text-center">Continuer avec Facebook</span>
                                <span style={{ width: '1.5rem' }}></span>
                            </button>
                            <button className="btn btn-outline-secondary w-100 mb-2 d-flex justify-content-between align-items-center">
                                <i className="bi bi-google me-2"></i>
                                <span className="flex-grow-1 text-center">Continuer avec Facebook</span>
                                <span style={{ width: '1.5rem' }}></span>
                            </button>
                            <button className="btn btn-light border w-100">
                                Se créer un Compte
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        </>
    );
}