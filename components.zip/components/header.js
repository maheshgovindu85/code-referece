import React from 'react';

export default function Header({ onLoginClick,onGmailLoginClick }) {
  return (
    <header className="d-flex justify-content-between align-items-center p-3 bg-light shadow-sm">
      <button className="btn btn-primary" onClick={onLoginClick}>
        Login
      </button>
       <button className="btn btn-primary" onClick={onGmailLoginClick}>
        Gmail Login
      </button>
    </header>
  );
}