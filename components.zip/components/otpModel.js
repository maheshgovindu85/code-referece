"use client";
import React, { useState, useRef, useEffect } from "react";

import styles from "./Modal.module.css";
export default function OtpModal({ show, onClose, phone  }) {
    const [otp, setOtp] = useState(Array(6).fill(""));
    const inputsRef = useRef([]);

    useEffect(() => {
        if (show) {
            setOtp(Array(6).fill(""));
        }
    }, [show]);


    if (!show) return null;

    const handleChange = (e, index) => {
        const value = e.target.value;

        // If user pastes the full OTP
        if (value.length > 1) {
            const chars = value.slice(0, 6).split("");
            const newOtp = [...otp];
            chars.forEach((char, i) => {
                if (i < 6) newOtp[i] = char.replace(/\D/, "");
            });
            setOtp(newOtp);
            const nextEmpty = chars.length >= 6 ? 5 : chars.length;
            inputsRef.current[nextEmpty]?.focus();
            return;
        }

        const newOtp = [...otp];
        newOtp[index] = value.replace(/\D/, ""); // Only digits
        setOtp(newOtp);

        // Auto focus next input
        if (value && index < 5) {
            inputsRef.current[index + 1]?.focus();
        }
    };

    const handleKeyDown = (e, index) => {
        if (e.key === "Backspace") {
            const newOtp = [...otp];
            if (otp[index]) {
                newOtp[index] = "";
                setOtp(newOtp);
            } else if (index > 0) {
                newOtp[index - 1] = "";
                setOtp(newOtp);
                inputsRef.current[index - 1]?.focus();
            }
        }
    };

    const handlePaste = (e) => {
        e.preventDefault();
        const paste = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6);
        if (!paste) return;
        const newOtp = [...otp];
        paste.split("").forEach((digit, i) => {
            newOtp[i] = digit;
        });
        setOtp(newOtp);
        inputsRef.current[paste.length - 1]?.focus();
    };



    const handleVerify = () => {
        if (otp === "123456") {
            alert("OTP verified!");
            onClose();
        } else {
            alert("Incorrect OTP");
        }
    };

    return (
        <>
            <style>
                {`
            .model-input-otp {
            border: 1px solid rgb(204, 204, 204);
            border-radius: 8px;
            width: max-content;
            padding: 5px;
            }

            .otp-box {
            width: 50px;
            height: 50px;
            font-size: 24px;
            border: none;
            outline: none;
            background: #fff;
            border-radius: 6px;
                color: #ccc;
            }

            .otp-box:focus {
              outline: none;
              box-shadow: none 
            }

            .otp-box::placeholder {
                color: #000;
                text-align: center;
            }
        `}
            </style>

            <div className="modal d-block" tabIndex={-1} style={{ background: "rgba(0,0,0,0.5)" }}>
                <div className={`modal-dialog modal-dialog-centered modal-fullscreen-sm-down ${styles["modal-top-spacing"]}`}>
                    <div className="modal-content rounded-4 shadow">
                        <div className="modal-header">
                            <button type="button" className="btn btn-close" onClick={onClose}>
                            </button>
                            <h5 className="modal-title text-center w-100">Confirmez votre numéro</h5>
                        </div>
                        <div className="modal-body text-center">
                            <p>Saisissez le code que vous avez reçu par email à <br></br> <strong>{phone}</strong></p>
                            <div className="d-flex model-input-otp mb-3">
                                {otp.map((digit, idx) => (
                                    <input
                                        key={idx}
                                        ref={(el) => (inputsRef.current[idx] = el)}
                                        type="text"
                                        inputMode="numeric"
                                        maxLength={1}
                                        className="otp-box text-center"
                                        value={digit}
                                        placeholder="-"
                                        onChange={(e) => handleChange(e, idx)}
                                        onKeyDown={(e) => handleKeyDown(e, idx)}
                                        onPaste={handlePaste}
                                    />
                                ))}



                            </div>


                        </div>

                        <div className="mt-3 modal-footer">
                            <div className="d-flex flex-column flex-sm-row w-100 gap-2 justify-content-between align-items-center">
                                <a href="#" className="text-decoration-underline">Choisissez une autre option</a>
                                <button className="btn btn-light   w-sm-auto mt-2 mt-sm-0" onClick={handleVerify}>
                                    Continuer
                                </button>
                            </div>
                        </div>


                    </div>
                </div>
            </div></>
    );
}
