
"use client";
import React, { useState, useEffect } from 'react';
import styles from "./Modal.module.css";
export default function GmailLoginModal({ show, onClose, onNext }) {
    const [phone, setPhone] = useState("");
    const [showPassword, setPassword] = useState(false);
    useEffect(() => {
        if (show) {
            setPhone("");
        }
    }, [show]);
    if (!show) return null;

    const handleSubmit = (e) => {
        e.preventDefault();
        if (phone.trim().length >= 6) {
            onNext(); // Show OTP modal
        } else {
            alert("Veuillez entrer un numéro valide.");
        }
    };
    return (
        <>
            <style>
                {`
           .selection-box{
               border: 1px solid #ccc;
                border-radius: 5px;
                padding: 3px;
           }
                .input-form-one {
                border: 0;
                border-bottom: 1px solid #ccc !important;
                border-radius: 0;
                
                }

              .form-contol-css {
               border: 0;
              }

                
                .form-contol-css:focus {
                 outline: none;
                 box-shadow: none 
                }

       `}
            </style>
            <div className="modal d-block" tabIndex="-1" style={{ background: 'rgba(0,0,0,0.5)' }}>
                <div className={`modal-dialog modal-dialog-centered modal-fullscreen-sm-down ${styles["modal-top-spacing"]}`}>


                    <div className="modal-content rounded-4 shadow">
                        <div className="modal-header">
                            <button type="button" className="btn-close" onClick={onClose}></button>
                            <h5 className="modal-title w-100 text-center fw-bold">Connexion</h5>
                        </div>
                        <form onSubmit={handleSubmit}>
                            <div className="modal-body">


                                <button className="btn btn-outline-secondary w-100 mb-2 d-flex justify-content-between align-items-center">
                                    <i className="bi bi-facebook"></i>
                                    <span className="flex-grow-1 text-center">Continuer avec Facebook</span>
                                    <span style={{ width: '1.5rem' }}></span>
                                </button>
                                <button className="btn btn-outline-secondary w-100 mb-2 d-flex justify-content-between align-items-center">
                                    <i className="bi bi-google me-2"></i>
                                    <span className="flex-grow-1 text-center">Continuer avec Facebook</span>
                                    <span style={{ width: '1.5rem' }}></span>
                                </button>
                                <div className="d-flex align-items-center my-3">
                                    <hr className="flex-grow-1" />
                                    <span className="mx-2 text-muted">ou</span>
                                    <hr className="flex-grow-1" />
                                </div>

                                <h6 className="mb-3">Nom Officail</h6>

                                <div className="mb-3 selection-box">
                                    <input type="tel" className="form-control form-contol-css input-form-one" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Numéro de téléphone" />
                                    <input type="tel" className="form-control form-contol-css" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Numéro de téléphone" />
                                </div>

                                <h6 className="mb-3">Nom Officail</h6>
                                <div className="d-flex align-items-center gap-3 my-3">
                                    <select className="form-select mb-2">
                                        <option>Mois</option>
                                        <option>India (+91)</option>
                                        <option>USA (+1)</option>
                                    </select>
                                    <select className="form-select mb-2">
                                        <option>Jour</option>
                                        <option>India (+91)</option>
                                        <option>USA (+1)</option>
                                    </select>
                                    <select className="form-select mb-2">
                                        <option>Annee</option>
                                        <option>India (+91)</option>
                                        <option>USA (+1)</option>
                                    </select>

                                </div>
                                <h6 className="mb-3">Coordonness</h6>

                                <div className='mb-3'>
                                    <label className='form-label'> hello </label>
                                    <input type="tel" className="form-control input-form-one" placeholder="Numéro de téléphone" />
                                </div>


                                <div className='mb-3'>
                                    <label className='form-label'> hello </label>
                                    <div className='input-group'>
                                        <input type={showPassword ? 'text' : 'password'} className='form-control ' placeholder='Mot de passe' />

                                        <button type='buton' className=' btn btn-link' onClick={() => setPassword(!showPassword)} >
                                            {showPassword ? 'cacher' : 'Afficher'}
                                        </button>
                                    </div>
                                </div>

                                <p className='text-muted small'>
                                    En cliquant sur <strong>Accepter  et continuer</strong>, Jaccepte les
                                    <a href='#'>Constions generaless</a>, et je reconnais avoir pris connaissance default
                                    <a href='#'>Politique de confidentialiated</a> de Turismo
                                </p>

                                <button className="btn btn-primary w-100 mb-3">Suivant</button>


                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </>
    );
}