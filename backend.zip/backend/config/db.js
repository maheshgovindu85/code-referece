const mysql = require('mysql2');
require('dotenv').config();

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'pmechtech0031',
  database: 'EmployeeAttendanceDB'
});

db.connect((err) => {
  if(err){
    console.log('MySQL Connection failed...');
    throw err
  }else {
    console.log('MySQL Connected...');
  }
  if (err) throw err;
});

module.exports = db;