const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/db');

exports.register = (req, res) => {
  const { name, email, password, role } = req.body;
  const hashedPassword = bcrypt.hashSync(password, 10);
  const query = `INSERT INTO employees (name, email, password, role) VALUES (?, ?, ?, ?)`;

  db.query(query, [name, email, hashedPassword, role], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: 'Employee registered successfully' });
  });
};

exports.login = (req, res) => {
  const { email, password } = req.body;
  const query = `SELECT * FROM employees WHERE email = ?`;

  db.query(query, [email], (err, results) => {
    if (err || results.length === 0) {
      return res.status(400).json(
        {
          status: false,
          message: 'Invalid email or password'
        });
    }

    const employee = results[0];
    const isMatch = bcrypt.compareSync(password, employee.password);

    if (!isMatch) return res.status(400).json({ error: 'Invalid password' });

    const token = jwt.sign(
      { id: employee.id, role: employee.role },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );


    res.json({
      status: true,
      token,
      employee,
      message: 'Login Success'
    });
  });
};
