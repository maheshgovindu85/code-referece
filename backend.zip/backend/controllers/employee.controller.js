// controllers/employee.controller.js
const db = require('../config/db');

exports.getEmployee = (req, res) => {
  const query = 'SELECT id, name, email, role FROM employees';
  
  db.query(query, (err, result) => {
    if (err) return res.status(500).json({ error: err,status:false, });
    if (result.length === 0) {
      return res.status(404).json({
        status: false,
        message: 'No employees found'
      });
    }
    res.json({
        status:true,
        data: result
      });
  });
};
