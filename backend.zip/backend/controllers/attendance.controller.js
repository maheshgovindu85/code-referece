const db = require('../config/db');

exports.punchIn = (req, res) => {
  const { employee_id, location, ip_address } = req.body;
  const query = `INSERT INTO attendance (employee_id, punch_in, location, ip_address) VALUES (?, NOW(), ?, ?)`;

  db.query(query, [employee_id, location, ip_address], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: 'Punch In Successful' });
  });
};

// Punch Out (attendance.controller.js)

exports.punchOut = (req, res) => {
  const { employee_id } = req.body;
  const query = `UPDATE attendance SET punch_out = NOW() WHERE employee_id = ? AND punch_out IS NULL`;

  db.query(query, [employee_id], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: 'Punch Out Successful' });
  });
};
exports.getAttendanceList = (req, res) => {
  const query = `
    SELECT 
      e.name AS employeeName, 
      e.id AS employee_id, 
      a.punch_in, 
      a.punch_out, 
      a.location,
      a.ip_address
    FROM 
      attendance a
    INNER JOIN 
      employees e
    ON 
      a.employee_id = e.id;
  `;

  db.query(query, (err, result) => {
    if (err) return res.status(500).json({ error: err, status: false });

    // Process the attendance records to group by employee_id
    const employeeMap = {};

    result.forEach(record => {
      if (!employeeMap[record.employee_id]) {
        employeeMap[record.employee_id] = {
          employeeName: record.employeeName,
          employee_id: record.employee_id,
          punchIn: [],
          punchOut: [],
          location: [],
          ip_address: []
        };
      }

      employeeMap[record.employee_id].punchIn.push(record.punch_in);
      if (record.punch_out) {
        employeeMap[record.employee_id].punchOut.push(record.punch_out);
      }
      employeeMap[record.employee_id].location.push(record.location);
      employeeMap[record.employee_id].ip_address.push(record.ip_address);
    });

    // Function to calculate the duration between punch_in and punch_out
    const calculateDuration = (punchIn, punchOut) => {
      const punchInDate = new Date(punchIn);
      const punchOutDate = punchOut ? new Date(punchOut) : new Date();
      const diffMs = punchOutDate - punchInDate;
      
      if (diffMs < 0) {
        // Avoid negative duration by returning 0 if punch_out < punch_in
        return "00:00:00";
      }

      const hours = Math.floor(diffMs / 3600000); // Hours
      const minutes = Math.floor((diffMs % 3600000) / 60000); // Minutes
      const seconds = Math.floor((diffMs % 60000) / 1000); // Seconds

      return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    };

    // Prepare the final list of attendance data
    const finalAttendanceList = Object.values(employeeMap).map(employee => {
      // Get the last punch-in and punch-out times
      const lastPunchIn = employee.punchIn[employee.punchIn.length - 1];
      const lastPunchOut = employee.punchOut[employee.punchOut.length - 1];
      const location = employee.location[employee.location.length - 1];
      const ip_address = employee.ip_address[employee.ip_address.length - 1];

      // Calculate the duration worked for this employee
      const duration = calculateDuration(lastPunchIn, lastPunchOut);

      return {
        employeeName: employee.employeeName,
        employee_id: employee.employee_id,
        punchIn: lastPunchIn,
        punchOut: lastPunchOut,
        duration: duration,
        location: location,
        ip_address: ip_address
      };
    });

    // Return the processed data as the response
    res.json({
      status: true,
      data: finalAttendanceList,
      message: 'Attendance List processed successfully',
    });
  });
};


exports.getAttendanceById = (req, res) => {
  const { employee_id } = req.body;
  const query = `SELECT * FROM attendance WHERE employee_id = ${employee_id}`;

  db.query(query, [employee_id], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json(
      {
        data: result,
        message: 'Attendance By Id'
      }
    );
  });
};
