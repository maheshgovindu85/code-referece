const express = require('express');
const { punchIn, punchOut, getAttendanceList, getAttendanceById } = require('../controllers/attendance.controller');
const router = express.Router();
const { isAdmin, isAdminOrEmployee } = require('../middleware/auth.middleware'); // Correct import

router.post('/punch-in', isAdminOrEmployee, punchIn);  
router.post('/punch-out', isAdminOrEmployee, punchOut);  
router.post('/getAttendanceList', isAdmin, getAttendanceList);  
router.post('/getAttendanceById', isAdminOrEmployee, getAttendanceById);

module.exports = router;
