const express = require('express');
const { punchIn, punchOut, getAttendanceList, getAttendanceById } = require('../controllers/attendance.controller');
const router = express.Router();

router.post('/punch-in', punchIn);
router.post('/punch-out', punchOut);
router.get('/getAttendanceList', getAttendanceList);
router.post('/getAttendanceById', getAttendanceById);

module.exports = router;