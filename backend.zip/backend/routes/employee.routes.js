const express = require('express');
const { getEmployee } = require('../controllers/employee.controller');
const router = express.Router();

router.get('/getEmployee', getEmployee);

module.exports = router;