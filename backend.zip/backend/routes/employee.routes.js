const express = require('express');
const { getEmployee } = require('../controllers/employee.controller');
const { isAdmin } = require('../middleware/auth.middleware');
const router = express.Router();

router.get('/getEmployee',isAdmin, getEmployee);

module.exports = router;