const db = require('../config/db');

exports.punchIn = (req, res) => {
  const { employee_id, location, ip_address } = req.body;
  const query = `INSERT INTO attendance (employee_id, punch_in, location, ip_address) VALUES (?, NOW(), ?, ?)`;

  db.query(query, [employee_id, location, ip_address], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: 'Punch In Successful' });
  });
};

// Punch Out (attendance.controller.js)

exports.punchOut = (req, res) => {
  const { employee_id } = req.body;
  const query = `UPDATE attendance SET punch_out = NOW() WHERE employee_id = ? AND punch_out IS NULL`;

  db.query(query, [employee_id], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: 'Punch Out Successful' });
  });
};

exports.getAttendanceList = (req, res) => {
  const { role, userId } = req.body;
  if (!role || !userId) {
    return res.status(400).json({ message: 'Role or User ID is missing in the request' });
  }

  const query = `
    SELECT 
      e.name AS employeeName, 
      e.id AS employee_id, 
      a.punch_in, 
      a.punch_out, 
      a.location,
      a.ip_address
    FROM 
      attendance a
    INNER JOIN 
      employees e
    ON 
      a.employee_id = e.id;
  `;

  if (role !== 'admin') {
    query += ` WHERE a.employee_id = ${{userId}}`; 
  }
  db.query(query, [role !== 'admin' ? userId : null], (err, result) => {
    if (err) return res.status(500).json({ error: err, status: false });

    const finalAttendanceList = result.map((record) => ({
      employeeName: record.employeeName,
      employee_id: record.employee_id,
      punchIn: record.punch_in,
      punchOut: record.punch_out,
      location: record.location,
      ip_address: record.ip_address,
      duration: calculateDuration(record.punch_in, record.punch_out),
    }));

    res.json({
      status: true,
      data: finalAttendanceList,
      message: 'Attendance List processed successfully',
    });
  });
};

function calculateDuration(punchIn, punchOut) {
  const punchInDate = new Date(punchIn);
  const punchOutDate = punchOut ? new Date(punchOut) : new Date();
  const diffMs = punchOutDate - punchInDate;

  if (diffMs < 0) {
    return '00:00:00';
  }

  const hours = Math.floor(diffMs / 3600000);
  const minutes = Math.floor((diffMs % 3600000) / 60000);
  const seconds = Math.floor((diffMs % 60000) / 1000);

  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

exports.getAttendanceById = (req, res) => {
  const { employee_id } = req.body;
  const query = `SELECT * FROM attendance WHERE employee_id = ${employee_id}`;

  db.query(query, [employee_id], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json(
      {
        data: result,
        message: 'Attendance By Id'
      }
    );
  });
};
