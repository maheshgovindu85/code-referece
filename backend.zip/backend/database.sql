CREATE DATABASE EmployeeAttendanceDB;
USE EmployeeAttendanceDB;
CREATE TABLE employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('employee', 'admin') DEFAULT 'employee'
);

CREATE TABLE attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    punch_in TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    punch_out TIMESTAMP NULL,
    location VARCHAR(255),
    ip_address VARCHAR(50),
    FOREIGN KEY (employee_id) REFERENCES employees(id)
);

select * from  employees;