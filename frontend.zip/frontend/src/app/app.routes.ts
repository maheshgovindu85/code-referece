import { Routes } from '@angular/router';
import { EmployeeDashboardComponent } from './components/employee-dashboard/employee-dashboard.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { authGuard } from './components/guards/auth.guard';
import { AttendanceMasterComponent } from './employee-attendence-master/attendance-master/attendance-master.component';

export const routes: Routes = [

    { path: '', redirectTo: '/login', pathMatch: 'full' },
    {
        path: "login",
        loadComponent() {
            return import('./components/login/login.component').then(
                (c) => c.LoginComponent
            );
        },
    },
    {
        path: "register",
        loadComponent() {
            return import('./components/register/register.component').then(
                (c) => c.RegisterComponent
            );
        },
    },

    {
        path: "register",
        loadComponent() {
            return import('./components/register/register.component').then(
                (c) => c.RegisterComponent
            );
        },
    },

    {
        path: "",
        loadComponent() {
            return import('./employee-attendence-master/attendance-master/attendance-master.component').then(
                (c) => c.AttendanceMasterComponent
            );
        },
        canActivate: [authGuard]

    },
    {
        path: "",
        component: AttendanceMasterComponent, canActivate: [authGuard],
        children: [
            { path: 'employee-dashboard', component: EmployeeDashboardComponent, canActivate: [authGuard] },
            { path: 'admin-dashboard', component: AdminDashboardComponent, canActivate: [authGuard] },
        ]

    }

    
];
