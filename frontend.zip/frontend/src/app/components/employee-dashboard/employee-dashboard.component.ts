import { Component } from '@angular/core';
import { AttendanceService } from '../services/attendance.service';
import { HttpClient } from '@angular/common/http';
import { LocalstorageService } from '../guards/localstorage.service';

@Component({
  selector: 'app-employee-dashboard',
  standalone: true,
  imports: [],
  templateUrl: './employee-dashboard.component.html',
  styleUrl: './employee-dashboard.component.scss'
})
export class EmployeeDashboardComponent {
attendanceRecords: any;
 

}
