export class Attendance {
}
