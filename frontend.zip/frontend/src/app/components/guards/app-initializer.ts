import { Observable, of } from 'rxjs';
import { AuthService } from '../services/auth.service';

export const appInitializer = (
  authService: AuthService
): (() => Observable<any>) => {
  return () => authService.isAuthenticated()
   ? of(null)
    : of(null);
};
