import { HttpInterceptorFn } from '@angular/common/http';
import { AuthService } from '../services/auth.service';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { LocalstorageService } from './localstorage.service';
import { catchError, throwError } from 'rxjs';

export const jwtInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);  
  const _router = inject(Router);  
  const _localStorage = inject(LocalstorageService);  
  const myToken = _localStorage.getItem('token');
  const clonedRequest = myToken 
    ? req.clone({
        setHeaders: {
          Authorization: `Bearer ${myToken}`
        }
      })
    : req;  
  return next(clonedRequest).pipe(
    catchError((err) => {
      console.error('Error occurred:', err);
      if (err.status === 401) {
        console.log('Authorization failed, user will be logged out.');
        // authService.logout();
        return throwError(() => new Error('Unauthorized - Invalid Token'));
      } else if (err.status === 400) {
        console.log('Bad Request, user will be logged out.');
        // authService.logout();
        return throwError(() => new Error('Unauthorized Exception'));
      } else {
        console.log('An unexpected error occurred:', err);
        return throwError(() => err);  
      }
    })
  );
};
