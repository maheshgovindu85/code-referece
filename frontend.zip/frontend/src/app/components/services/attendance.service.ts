import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AttendanceService {

  constructor(private http: HttpClient) {}

  punchIn(employee_id: number, location: string, ip_address: string): Observable<any> {
    return this.http.post(`${environment.apiUrl}/attendance/punch-in`, { employee_id, location, ip_address });
  }
  
  punchOut(employee_id: number): Observable<any> {
    return this.http.post(`${environment.apiUrl}/attendance/punch-out`, { employee_id });
  }

  getAttendanceId(employee_id: number): Observable<any> {
    return this.http.post(`${environment.apiUrl}/attendance/getAttendanceById`, { employee_id });
  }

  getAttendanceList(): Observable<any> {
    return this.http.get(`${environment.apiUrl}/attendance/getAttendanceList`);
  }
}
