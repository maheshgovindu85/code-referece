import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  http = inject(HttpClient)
  router = inject(Router)
  constructor() { }

  getEmployeeList(): Observable<any> {
    return this.http.get(`${environment.apiUrl}/employee/getEmployee`);
  }
}
