import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Router } from '@angular/router';
import { LocalstorageService } from '../guards/localstorage.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  http = inject(HttpClient)
  router = inject(Router)
  constructor( private _localstorage: LocalstorageService,) {}

  login(email: string, password: string): Observable<any> {
    return this.http.post(`${environment.apiUrl}/auth/login`, { email, password });
  }
  
  register(employee: any): Observable<any> {
    return this.http.post(`${environment.apiUrl}/auth/register`, employee);
  }
  
  logout() {
    this._localstorage.removeItem('token');
    this.router.navigate(['/']);
  }

  isAuthenticated(): boolean {
    return !!this._localstorage.getItem('token');
  }
}
