import { Component, inject } from '@angular/core';
import { AttendanceService } from '../../services/attendance.service';

@Component({
  selector: 'app-attendance-history',
  standalone: true,
  imports: [],
  templateUrl: './attendance-history.component.html',
  styleUrl: './attendance-history.component.scss'
})
export class AttendanceHistoryComponent {
  attendanceRecords: any[] = [];;
  attendanceService = inject(AttendanceService)
  ngOnInit() {
    this.getAttendance();
  }
  

  getAttendance() {
    this.attendanceService.getAttendanceList().subscribe(data => {
      this.attendanceRecords = data['data'];
    });
  }
}
