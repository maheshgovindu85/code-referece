import { Component, inject } from '@angular/core';
import { EmployeeService } from '../../services/employee.service';

@Component({
  selector: 'app-employees-list',
  standalone: true,
  imports: [],
  templateUrl: './employees-list.component.html',
  styleUrl: './employees-list.component.scss'
})
export class EmployeesListComponent {
  employeeList: any[] = [];
  employeeService = inject(EmployeeService)

  constructor(
  ) { }

  ngOnInit() {
    this.getList();
  }

  getList() {
    this.employeeService.getEmployeeList().subscribe(data => {
      this.employeeList = data['data'];
    });
  }


}
