import { Component } from '@angular/core';
import { EmployeeService } from '../services/employee.service';
import { AttendanceService } from '../services/attendance.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [],
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.scss'
})
export class AdminDashboardComponent {
  employee: any;
  employeeList: any[] = [];
  attendanceRecords: any[] = [];;

  constructor(
    private employeeService: EmployeeService,
    private attendanceService: AttendanceService,

  ) {}

  ngOnInit() {
    this.getList();
    this.getAttendance();
  }
  
  getList() {
    this.employeeService.getEmployeeList().subscribe(data => {
      this.employeeList = data['data'];
    });
  }

  getAttendance() {
    this.attendanceService.getAttendanceList().subscribe(data => {
      this.attendanceRecords = data['data'];
    });
  }


}
