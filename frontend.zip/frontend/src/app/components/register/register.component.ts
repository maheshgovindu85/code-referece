import { Component, inject } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.scss'
})
export class RegisterComponent {
  employee = {
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    role:''
  };
  loading = false;  
  authService = inject(AuthService);
  router = inject(Router);
  constructor(
  ) {}

  onSubmit(): void {
    if (this.employee.password !== this.employee.confirmPassword) {
      alert('Passwords do not match')
      return;
    }

    this.loading = true;
    this.authService.register(this.employee).subscribe({
      next: () => {
        alert('Registration successful! Please login.');
        this.router.navigate(['/login']);
      },
      error: (error) => {
        this.loading = false;
        alert({
          severity: 'error',
          summary: 'Error',
          detail: error.error.message || 'Registration failed'
        });
      }
    });
  }
}
