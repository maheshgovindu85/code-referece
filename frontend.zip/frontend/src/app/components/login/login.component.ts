import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LocalstorageService } from '../guards/localstorage.service';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {
  email: string = '';
  password: string = '';
  private currentUserSubject = new BehaviorSubject<any>(null);
  constructor(
    private authService: AuthService,
    private router: Router,
    private _localstorage: LocalstorageService,) { }

  onSubmit() {
    this.authService.login(this.email, this.password).subscribe(response => {
      if (response.status) {
        this.authService.setLocalStorage(response)
        this.currentUserSubject.next(response.employee);
        alert(response.message);
        if (response.employee.role === 'admin') {
          this.router.navigate(['/admin']);
        } else {
          this.router.navigate(['/employee']);
        }
      } else {
        alert(response.message);
      }

    });
  }
}
