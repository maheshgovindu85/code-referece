import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LocalstorageService } from '../guards/localstorage.service';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {
  email: string = '';
  password: string = '';
  private currentUserSubject = new BehaviorSubject<any>(null);
  constructor(
    private authService: AuthService,
    private router: Router,
    private _localstorage: LocalstorageService,) { }

  onSubmit() {
    this.authService.login(this.email, this.password).subscribe(response => {
      console.log('response', response);
      if (response.status) {
        this._localstorage.setItem('token', response.token);
        this._localstorage.setItem('employee', JSON.stringify(response.employee));
        this._localstorage.setItem('employeeId',response.employee.id);
        this.currentUserSubject.next(response.employee);
        alert(response.error);
        if (response.employee.role === 'admin') {
          this.router.navigate(['/admin-dashboard']);
        } else {
          this.router.navigate(['/employee-dashboard']);
        }
      } else {
        alert(response.error);
      }

    });
  }
}
