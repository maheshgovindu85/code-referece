import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AttendanceMasterComponent } from './attendance-master.component';

describe('AttendanceMasterComponent', () => {
  let component: AttendanceMasterComponent;
  let fixture: ComponentFixture<AttendanceMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AttendanceMasterComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AttendanceMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
