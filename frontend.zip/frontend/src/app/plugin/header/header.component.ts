import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { LocalstorageService } from '../../components/guards/localstorage.service';
import { AttendanceService } from '../../components/services/attendance.service';
import { AuthService } from '../../components/services/auth.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent {

  employee: any;
  attendanceRecords: any[] = [];
  isPunchedIn = false;
  duration = '00:00:00';
  private startTime: Date | null = null;
  private timer: any;
  employeeId!: number;
  constructor(
    private attendanceService: AttendanceService,
    private http: HttpClient,
    private _localstorage: LocalstorageService,
    private authService: AuthService,
  ) { }

  ngOnInit() {
    this.employeeId = +this._localstorage.getItem('employeeId')!;
    this.getEmployeeDetails();
    this.getAttendanceByEmpId();
    
  }

  getAttendanceByEmpId() {
    this.attendanceService.getAttendanceId(this.employee?.id).subscribe(res => {
      if (res['data'] && res['data'].length > 0) {
        debugger
        const latestAttendance = res['data'][res['data'].length - 1];  // Get the latest attendance record
        if (latestAttendance.punch_in && !latestAttendance.punch_out) {
          this.isPunchedIn = true;
          this.startTime = new Date(latestAttendance.punch_in);
          this.startTimer(); 
        } else {
          this.isPunchedIn = false;
          this.duration = '00:00:00';
        }
      }
    });
  }
  

  
  getEmployeeDetails() {
    this.employee = JSON.parse(this._localstorage.getItem('employee')!);
  }

  punchIn(): void {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return;
    }

    // Step 1: Get the current location
    navigator.geolocation.getCurrentPosition((position) => {
      const location = `${position.coords.latitude},${position.coords.longitude}`;

      // Step 2: Get the IP address
      this.http.get<any>('https://api.ipify.org?format=json').subscribe({
        next: (response) => {
          const ipAddress = response.ip;

          // Step 3: Call the punchIn service with location and IP address
          this.attendanceService.punchIn(this.employee.id, location, ipAddress).subscribe({
            next: () => {
              alert('Punched in successfully.');
              this.isPunchedIn = true;
              this.getAttendanceByEmpId()
              this.startTime = new Date();
              this.startTimer();
            },
            error: (error) => {
              alert('Failed to punch in. ' + (error.error.message || 'Please try again.')
              );
            }
          });
        },
        error: (err) => {
          alert('Failed to get IP address.');
        }
      });
    });
  }

  punchOut() {
    this.attendanceService.punchOut(this.employee.id).subscribe(() => {
      this.isPunchedIn = false;
      this.startTime = new Date();
      this.startTimer();
    });
  }

  private startTimer() {
    this.timer = setInterval(() => {
      if (this.startTime) {
        const diff = new Date().getTime() - this.startTime.getTime();
        const hours = Math.floor(diff / 3600000);
        const minutes = Math.floor((diff % 3600000) / 60000);
        const seconds = Math.floor((diff % 60000) / 1000);
        this.duration = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
      }
    }, 1000);
  }

  private stopTimer() {
    if (this.timer) {
      clearInterval(this.timer);
      this.duration = '00:00:00';
    }
  }

  logout() {
    this.authService.logout();
  }
}
