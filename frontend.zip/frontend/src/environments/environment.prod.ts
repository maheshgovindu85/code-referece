export const environment = {
    production: true,
    apiUrl: 'https://your-production-api.com/api',
    // Add more production-specific variables here
  };